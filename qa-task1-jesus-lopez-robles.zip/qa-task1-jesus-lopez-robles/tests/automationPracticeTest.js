const data = require('../test_data/data');
const page = require('../page_objects/page')
const home = require('../page_objects/homePage');
const login = require('../page_objects/loginPage');
const create = require('../page_objects/createAccountPage');
const myAccount = require('../page_objects/myAccountPage');
const actions = require('../base/actions');

beforeAll(function (){
    page.openUrl()
})

describe("Creat new account validations", function() {
    it("Error message displayed when try to create an account with emty field", function(){
        home.goToLoginPage();
        login.createNewAccount('');
        expect(actions.isElementDisplayed(login.createErrorMessage));
    });

    it("Error message displayed when try to enter with empty credentials", function(){
        login.enterUserCredentials('','');
        expect(actions.isElementDisplayed(login.loginErrorMessage));
    });

    it("Fill the form for a new account", function(){
        login.createNewAccount(data.email);
        create.fillCompleteForm(data.firstName, data.lastName, data.email, data.password, data.dayOfBirth, data.monthOfBirth, data.yearOfBirth, data.address, data.city, data.state, data.zipCode, data.mobile, data.alias);
        expect(actions.isElementDisplayed(myAccount.myAccountHeaderLbl));
    });
});