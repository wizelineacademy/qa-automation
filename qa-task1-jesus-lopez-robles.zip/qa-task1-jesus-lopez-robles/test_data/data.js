const Data = function () {

  var randomNumber = Math.floor((Math.random() * 1000) + 1).toString();

   this.email = 'testautomation'+randomNumber+'@gmail.com';
   this.password = 'Herb@1234';
   this.firstName = 'Automation';
   this.lastName = 'Test';
   this.dayOfBirth = '25';
   this.monthOfBirth = 'November';
   this.yearOfBirth = '1990';
   this.address = '950 W 190th St';
   this.zipCode ='90502';
   this.city ='Torrance';
   this.state = 'California';
   this.mobile = '3104109600';
   this.alias = 'Work';
 }
 module.exports = new Data();
