const actions = require('../base/actions');

/**
 * @description Page Object for Login Page.
 */
function LoginPage() {
    this.headerLbl = element(by.css('.page-heading'));

    //#region Create An Account Objects
    this.createNewAccountTxt = element(by.id('email_create'));
    this.createNewAccountBtn = element(by.id('SubmitCreate'));
    this.createErrorMessage = element(by.id('create_account_error'));
    //#endregion

    //#region Create An Account Objects
    this.emailTxt = element(by.id('email'));
    this.passwordTxt = element(by.id('passwd'));
    this.SubmitBtn = element(by.id('SubmitLogin'));
    this.loginErrorMessage = element(by.css('#center_column > div.alert.alert-danger'));
    //#endregion


    /**
   * @description Function used to enter credentials for Login then click on Login Button
   * @method enterUserCredentials
   * @param {String} email
   * @param {String} pass
   */
    this.enterUserCredentials = (email, psw) =>{
        actions.enterText(this.emailTxt, email);
        actions.enterText(this.passwordTxt, psw);
        actions.clickToElement(this.SubmitBtn);
    }

    /**
   * @description Function used to enter create new account.
   * @method createNewAccount
   * @param {String} email
   */
    this.createNewAccount = (email) =>{
    actions.enterText(this.createNewAccountTxt, email);
    actions.clickToElement(this.createNewAccountBtn);
    }
}

module.exports = new LoginPage();
