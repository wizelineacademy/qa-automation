const actions = require('../base/actions');

/**
 * @description Page Object for Create An Account Page.
 */
function CreateAccountPage() {
    //#region Personal Information Objects
    this.mrRadioBtn = element(by.id('id_gender1'));
    this.mrsRadioBtn = element(by.id('uniform-id_gender2'));
    this.firstNameTxt = element(by.id('customer_firstname'));
    this.lastNameTxt = element(by.id('customer_lastname'));
    this.emailTxt = element(by.id('email'));
    this.passwordTxt = element(by.id('passwd'));
    this.dayDD = element(by.id('days'));
    this.monthDD = element(by.id('months'));
    this.yearDD = element(by.id('years'));
    //#endregion

    //#region Address Information Objects
    this.addressFirstNameTxt = element(by.id('firstname'));
    this.addressLastNameTxt = element(by.id('lastname'));
    this.CompanyTxt = element(by.id('company'));
    this.addressTxt = element(by.id('address1'));
    this.stateDD = element(by.id('id_state'));
    this.cityTxt = element(by.id('city'));
    this.zipCodeTxt = element(by.id('postcode'));
    this.countryDD = element(by.id('id_country'));
    this.homePhoneTxt = element(by.id('phone'));
    this.mobilePhoneTxt = element(by.id('phone_mobile'));
    this.addressAliasTxt = element(by.css('input#alias.form-control'));
    this.submitBtn = element(by.id('submitAccount'));
    //#endregion

   /**
   * @description Function used to fill the personal information section.
   * @method fillPersonalInformation
   */
    this.fillPersonalInformation = (name, last_name, email, psw, day, month, year) =>{
        actions.clickToElement(this.mrRadioBtn);
        actions.enterText(this.firstNameTxt, name);
        actions.enterText(this.lastNameTxt, last_name);
        actions.clearElementText(this.emailTxt);
        actions.enterText(this.emailTxt, email);
        actions.enterText(this.passwordTxt, psw);
        this.dayDD.element(by.cssContainingText("option", day)).click();
        this.monthDD.element(by.cssContainingText("option", month)).click();
        this.yearDD.element(by.cssContainingText("option", year)).click();

    }

    /**
   * @description Function used to fill the address section.
   * @method fillAddressInformation
   */
    this.fillAddressInformation = (name, last_name, address, city, state, zip, phone, alias) =>{
        actions.enterText(this.addressFirstNameTxt, name);
        actions.clearElementText(this.addressAliasTxt);
        actions.enterText(this.addressLastNameTxt, last_name);
        actions.enterText(this.addressTxt, address);
        actions.enterText(this.cityTxt,city);
        this.stateDD.element(by.cssContainingText("option", state)).click();
        actions.clearElementText(this.zipCodeTxt);
        actions.enterText(this.zipCodeTxt, zip);
        actions.enterText(this.homePhoneTxt, phone);
        actions.enterText(this.mobilePhoneTxt, phone);
        actions.clearElementText(this.addressAliasTxt);
        actions.enterText(this.addressAliasTxt, alias);

    }

    this.fillCompleteForm = (name, last_name, email, psw, day, month, year, address, city, state, zip, phone, alias) =>{
        this.fillPersonalInformation(name, last_name, email, psw, day, month, year);
        this.fillAddressInformation(name, last_name, address, city, state, zip, phone, alias);
        actions.clickToElement(this.submitBtn);
    }


}

module.exports = new CreateAccountPage();