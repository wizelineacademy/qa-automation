
const actions = require('../base/actions');
const loginPage = require('../page_objects/loginPage');

/**
 * @description Page Object for Home Page.
 */
    function HomePage(){
    this.signInLnk = element(by.css('a.login'));

    /**
     * @description Method to click on signIn link and wait until Login Page is displayed.
     * @method goToLoginPage
     */
    this.goToLoginPage = () =>{
        actions.clickToElement(this.signInLnk);
        actions.isElementDisplayed(loginPage.headerLbl);
    };

}

module.exports = new HomePage();
