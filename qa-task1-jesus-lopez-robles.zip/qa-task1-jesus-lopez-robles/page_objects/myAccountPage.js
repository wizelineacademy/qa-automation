/**
 * @description Page Object for My Account Page.
 */
function MyAccountPage() {
    this.myAccountHeaderLbl = element(by.css('h1.page-heading'));

}

module.exports = new MyAccountPage();